{{- define "bb-common.istio.authorization-policies.generate.from-definition" }}
  {{- $ctx := index . 0 }}
  {{- $netpol := index . 1 }}
  {{- $definitionKey := index . 2 }}

  {{- $remote := include "bb-common.network-policies.ingress.parse.definition-remote-key" $definitionKey | fromYaml }}
  {{- $ingressRule := first $netpol.spec.ingress }}
  {{- $fromRules := list }}
  {{- $canTranslate := true }}
  {{- $allowsAllSources := false }}
  {{- $selector := $netpol.spec.podSelector }}
  {{- if hasKey $selector "matchExpressions" }}
    {{- $canTranslate = false }}
  {{- end }}

  {{- range $peer := $ingressRule.from }}
    {{- $source := dict }}
    {{- $translated := false }}

    {{- if hasKey $peer "ipBlock" }}
      {{- $_ := set $source "ipBlocks" (list $peer.ipBlock.cidr) }}
      {{- if $peer.ipBlock.except }}
        {{- $_ := set $source "notIpBlocks" $peer.ipBlock.except }}
      {{- end }}
      {{- $translated = true }}
    {{- else if hasKey $peer "namespaceSelector" }}
      {{- if empty $peer.namespaceSelector }}
        {{- $_ := set $source "namespaces" (list "*") }}
        {{- $translated = true }}
      {{- else }}
        {{- $matchLabels := dig "matchLabels" dict $peer.namespaceSelector }}
        {{- $matchExpressions := dig "matchExpressions" list $peer.namespaceSelector }}
        {{- if and (empty $matchExpressions) (eq (len $matchLabels) 1) (hasKey $matchLabels "kubernetes.io/metadata.name") }}
          {{- $namespace := index $matchLabels "kubernetes.io/metadata.name" }}
          {{- if $namespace }}
            {{- $_ := set $source "namespaces" (list $namespace) }}
            {{- $translated = true }}
          {{- end }}
        {{- end }}
      {{- end }}
    {{- else if hasKey $peer "podSelector" }}
      {{- $_ := set $source "namespaces" (list $ctx.Release.Namespace) }}
      {{- $translated = true }}
    {{- else if empty $peer }}
      {{- $allowsAllSources = true }}
      {{- $translated = true }}
    {{- end }}

    {{- if and $translated (not (empty $peer)) }}
      {{- $fromRules = append $fromRules (dict "source" $source) }}
    {{- else if not $translated }}
      {{- $canTranslate = false }}
    {{- end }}
  {{- end }}

  {{- $rule := dict }}
  {{- if not $allowsAllSources }}
    {{- $_ := set $rule "from" $fromRules }}
  {{- end }}

  {{- if $ingressRule.ports }}
    {{- $toRules := list }}
    {{- range $port := $ingressRule.ports }}
      {{- if not (regexMatch `^[0-9]+$` ($port.port | toString)) }}
        {{- $canTranslate = false }}
        {{- continue }}
      {{- end }}

      {{- $portList := list ($port.port | toString) }}
      {{- if $port.endPort }}
        {{- $portList = list }}
        {{- range $p := (seq ($port.port | int) ($port.endPort | int) | split " ") }}
          {{- $portList = append $portList $p }}
        {{- end }}
      {{- end }}
      {{- $toRules = append $toRules (dict "operation" (dict "ports" ($portList | toStrings))) }}
    {{- end }}
    {{- $_ := set $rule "to" $toRules }}
  {{- end }}

  {{- if and $canTranslate (or $fromRules $allowsAllSources) }}
    {{- $annotations := deepCopy $netpol.metadata.annotations }}
    {{- $_ := set $annotations "generated.authorization-policies.bigbang.dev/from-definition" $remote.definitionName }}
    {{- dict
      "apiVersion" "security.istio.io/v1"
      "kind" "AuthorizationPolicy"
      "metadata" (dict
        "name" $netpol.metadata.name
        "namespace" $ctx.Release.Namespace
        "labels" (deepCopy $netpol.metadata.labels)
        "annotations" $annotations
      )
      "spec" (dict
        "action" "ALLOW"
        "selector" $selector
        "rules" (list $rule)
      )
      | toYaml
    }}
  {{- else }}
    {{- dict | toYaml }}
  {{- end }}
{{- end }}
