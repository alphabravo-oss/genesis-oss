{{- define "bb-common.istio.authorization-policies.defaults.render" }}
  {{- $ctx := . }}
  {{- $authzpols := list }}

  {{- $istio := $ctx.Values.istio | default dict }}
  {{- $authzPolicies := $istio.authorizationPolicies | default dict }}
  {{- $authzDefaults := $authzPolicies.defaults | default dict }}
  {{- $ingressDefaults := dig "ingress" "defaults" dict $ctx.Values.networkPolicies }}

  {{- $denyAllEnabled := true }}
  {{- if hasKey $authzDefaults "denyAll" }}
    {{- $denyAllEnabled = dig "denyAll" "enabled" true $authzDefaults }}
  {{- else }}
    {{- $denyAllEnabled = dig "denyAll" "enabled" true $ingressDefaults }}
  {{- end }}

  {{- $allowInNamespaceEnabled := eq (include "bb-common.istio.authorization-policies.defaults.allow-in-namespace-enabled" $ctx) "true" }}

  {{- if $denyAllEnabled }}
    {{- $authzpols = append $authzpols (include "bb-common.istio.authorization-policies.defaults.allow-nothing" $ctx | fromYaml) }}
  {{- end }}
  {{- if $allowInNamespaceEnabled }}
    {{- $authzpols = append $authzpols (include "bb-common.istio.authorization-policies.defaults.allow-all-in-ns" $ctx | fromYaml) }}
  {{- end }}

  {{- if dig "defaultsAsHooks" "enabled" false $ctx.Values.networkPolicies }}
    {{- $defaultHooks := dig "defaultsAsHooks" dict $ctx.Values.networkPolicies }}
    {{- $defaultHookTypes := list "pre-install" "pre-upgrade" "post-delete" }}
    {{- $defaultWeight := -5 }}
    {{- $defaultDeletePolicies := list "hook-succeeded" "before-hook-creation" }}

    {{- $hooks := dig "hooks" $defaultHookTypes $defaultHooks }}
    {{- $weight := dig "weight" $defaultWeight $defaultHooks }}
    {{- $deletePolicies := dig "deletePolicies" $defaultDeletePolicies $defaultHooks }}

    {{- $authzpols = concat $authzpols ((include "bb-common.utils.as-hooks" (list $authzpols $hooks $weight $deletePolicies)) | fromYamlArray) }}
  {{- end }}

  {{- $authzpols | toYaml }}
{{- end }}

{{- /* Resolves the allowInNamespace toggle: istio.authorizationPolicies.defaults
       wins, then networkPolicies.ingress.defaults (same fallback as the render
       above). The routes authservice generator uses this too, to decide whether
       to restate the namespace default at the waypoint. */ -}}
{{- define "bb-common.istio.authorization-policies.defaults.allow-in-namespace-enabled" -}}
{{- $authzDefaults := dig "authorizationPolicies" "defaults" dict (.Values.istio | default dict) -}}
{{- $ingressDefaults := dig "ingress" "defaults" dict (.Values.networkPolicies | default dict) -}}
{{- if hasKey $authzDefaults "allowInNamespace" -}}
{{- dig "allowInNamespace" "enabled" true $authzDefaults -}}
{{- else -}}
{{- dig "allowInNamespace" "enabled" true $ingressDefaults -}}
{{- end -}}
{{- end -}}