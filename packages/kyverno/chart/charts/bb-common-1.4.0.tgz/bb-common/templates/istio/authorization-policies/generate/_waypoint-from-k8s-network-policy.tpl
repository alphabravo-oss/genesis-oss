{{- /*
Waypoint-bound twin of "generate.from-k8s-network-policy".

The base generator's policy is selector-bound, which is enforced by ztunnel at
the workload. A waypoint only evaluates policies bound with targetRefs, so when
the workload's Service is enrolled on the waypoint each declared client also
needs the same ALLOW attached to the Service. Without it the waypoint denies
the client.

This wraps the base generator and rebinds the result:
  - selector becomes targetRefs to the route's Service
  - to.operation.ports uses the Service port (what the client addressed)
    instead of the container port
  - the name gets a -waypoint suffix and a from-route annotation
*/}}
{{- define "bb-common.istio.authorization-policies.generate.waypoint-from-k8s-network-policy" }}
  {{- $ctx := index . 0 }}
  {{- $netpol := index . 1 }}
  {{- $ruleKey := index . 2 }}
  {{- $ruleValue := index . 3 }}
  {{- $name := index . 4 }}
  {{- $labels := index . 5 }}
  {{- $annotations := index . 6 }}
  {{- $local := index . 7 }}
  {{- $match := index . 8 }}

  {{- /* The base generator only reads the netpol's name (for naming) and its
         ingress ports, so hand it a minimal shell scoped to the Service port. */}}
  {{- $ports := list (dict "port" (int $match.port) "protocol" "TCP") }}
  {{- $shell := dict
    "metadata" (dict "name" $netpol.metadata.name)
    "spec" (dict
      "podSelector" dict
      "ingress" (list (dict "ports" $ports))
    )
  }}

  {{- $authz := include "bb-common.istio.authorization-policies.generate.from-k8s-network-policy" (list $ctx $shell $ruleKey $ruleValue $name $labels $annotations $local) | fromYaml }}

  {{- $_ := unset $authz.spec "selector" }}
  {{- $_ := set $authz.spec "targetRefs" (list (dict "group" "" "kind" "Service" "name" $match.service)) }}
  {{- $_ := set $authz.metadata "name" (printf "%s-waypoint" $authz.metadata.name) }}
  {{- $_ := set $authz.metadata.annotations "generated.authorization-policies.bigbang.dev/from-route" $match.route }}

  {{- $authz | toYaml }}
{{- end }}
