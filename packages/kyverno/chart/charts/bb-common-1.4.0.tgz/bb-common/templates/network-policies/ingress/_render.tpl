{{- define "bb-common.network-policies.ingress.render" }}
  {{- $ctx := . }}
  {{- $netpols := list }}
  {{- $authzpols := list }}

  {{- $ingressPolicies := dig "ingress" "to" dict .Values.networkPolicies }}
  {{- if $ingressPolicies }}
    {{- $ingressPolicies = tpl ($ingressPolicies | toYaml) $ | fromYaml }}
  {{- end }}

  {{- $generators := dict
    "k8s" "bb-common.network-policies.ingress.generate.from-k8s-shorthand"
    "cidr" "bb-common.network-policies.ingress.generate.from-cidr-shorthand"
    "definition" "bb-common.network-policies.ingress.generate.from-definition"
    "literal" "bb-common.network-policies.ingress.generate.from-spec-literal"
  }}

  {{- range $localKey, $localConfig := $ingressPolicies }}
    {{- $localParsed := include "bb-common.network-policies.ingress.parse.local-key" $localKey | fromYaml }}

    {{- /* Waypoint mirroring: if this entry's workload sits behind an
           authservice-protected route (ambient mode), Service traffic from its
           clients lands on the waypoint pod, where neither the workload netpol
           nor the ztunnel-enforced authz below apply. Find the route by
           selector + port and mirror each client onto the waypoint. */}}
    {{- $waypointMatch := dict }}
    {{- if eq (include "bb-common.istio.waypoint.enabled" $ctx) "true" }}
      {{- $localSelector := (include "bb-common.network-policies.new" (list $localParsed.name $localConfig.podSelector "ingress") | fromYaml).spec.podSelector }}
      {{- $matchResult := include "bb-common.routes.inbound.match-authservice-route" (list $ctx $localSelector $localParsed.ports) | trim }}
      {{- if $matchResult }}
        {{- $waypointMatch = $matchResult | fromYaml }}
      {{- end }}
    {{- end }}

    {{- range $remoteType, $generator := $generators }}
      {{- range $remoteKey, $remoteConfig := dig "from" $remoteType dict $localConfig }}
        {{- $isEnabled := or (and (kindIs "map" $remoteConfig) (dig "enabled" true $remoteConfig)) (and (kindIs "bool" $remoteConfig) $remoteConfig) }}

        {{- if not $isEnabled }}
          {{- continue }}
        {{- end }}

        {{- $netpol := include "bb-common.network-policies.new" (list $localParsed.name $localConfig.podSelector "ingress") | fromYaml }}
        {{- $name := printf "allow-ingress-to-%s" $localParsed.name }}
        {{- $name = include "bb-common.prepend-release-name" (list $ctx $name "networkPolicies") }}
        {{- $labels := include "bb-common.network-policies.default-labels" "ingress" | fromYaml }}
        {{- $annotations := dict  "generated.network-policies.bigbang.dev/local-key" $localKey }}

        {{- if $localConfig.podSelector }}
          {{- $_ := set $annotations "generated.network-policies.bigbang.dev/with-local-selector-override" ($localConfig.podSelector | toYaml) }}
        {{- end }}

        {{- if and $localParsed.protocol (not (eq $localParsed.protocol "TCP")) }}
          {{- $name = printf "%s-%s" $name (lower $localParsed.protocol) }}
        {{- end }}

        {{- $args := list $ctx $netpol $remoteKey $remoteConfig $name $labels $annotations $localParsed }}
        {{- $netpol = include $generator $args | fromYaml }}
        {{- $netpol = merge $netpol (include "bb-common.network-policies.metadata-overrides" (list $localConfig $remoteConfig) | fromYaml) }}
        {{- $netpols = append $netpols $netpol }}

        {{- /* Admit this client to the waypoint pod over HBONE (15008), where
               its Service traffic actually lands. */}}
        {{- if and $waypointMatch.route (eq $remoteType "k8s") }}
          {{- $waypointName := include "bb-common.istio.waypoint.name" $ctx }}
          {{- $mirrorNetpol := dict
            "apiVersion" "networking.k8s.io/v1"
            "kind" "NetworkPolicy"
            "spec" (dict
              "podSelector" (dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" $waypointName))
              "policyTypes" (list "Ingress")
            )
          }}
          {{- $mirrorName := printf "allow-ingress-to-%s-waypoint" $waypointMatch.route }}
          {{- $mirrorName = include "bb-common.prepend-release-name" (list $ctx $mirrorName "networkPolicies") }}
          {{- $mirrorLocal := dict "name" $localParsed.name "protocol" "TCP" "ports" (list 15008) "hasPortRange" false }}
          {{- $mirrorAnnotations := dict
            "generated.network-policies.bigbang.dev/local-key" $localKey
            "generated.network-policies.bigbang.dev/from-route" $waypointMatch.route
          }}
          {{- $mirrorLabels := include "bb-common.network-policies.default-labels" "ingress" | fromYaml }}
          {{- $mirrorArgs := list $ctx $mirrorNetpol $remoteKey $remoteConfig $mirrorName $mirrorLabels $mirrorAnnotations $mirrorLocal }}
          {{- $mirrorNetpol = include $generator $mirrorArgs | fromYaml }}
          {{- $mirrorNetpol = merge $mirrorNetpol (include "bb-common.network-policies.metadata-overrides" (list $localConfig $remoteConfig) | fromYaml) }}
          {{- $netpols = append $netpols $mirrorNetpol }}
        {{- end }}

        {{- $istio := $ctx.Values.istio | default dict }}
        {{- if not $istio.enabled }}
          {{- continue }}
        {{- end }}

        {{- $authzpolsEnabled := eq (include "bb-common.istio.authorization-policies.enabled" $ctx) "true" }}
        {{- if not $authzpolsEnabled }}
          {{- continue }}
        {{- end }}

        {{- if eq (include "bb-common.istio.authorization-policies.generate-from-netpol.enabled" $ctx) "true" }}
          {{- if eq $remoteType "k8s" }}
            {{- $authzPolicy := include "bb-common.istio.authorization-policies.generate.from-k8s-network-policy" $args | fromYaml }}
            {{- $authzPolicy := merge $authzPolicy (include "bb-common.network-policies.metadata-overrides" (list $localConfig $remoteConfig) | fromYaml) }}
            {{- $authzpols = append $authzpols $authzPolicy }}

            {{- /* The policy above is selector-bound and enforced at ztunnel,
                   which the waypoint ignores. Emit a twin bound to the route's
                   Service so the waypoint admits this client too. */}}
            {{- if $waypointMatch.route }}
              {{- $twinAnnotations := dict "generated.network-policies.bigbang.dev/local-key" $localKey }}
              {{- $twinArgs := list $ctx $netpol $remoteKey $remoteConfig $name $labels $twinAnnotations $localParsed $waypointMatch }}
              {{- $twinPolicy := include "bb-common.istio.authorization-policies.generate.waypoint-from-k8s-network-policy" $twinArgs | fromYaml }}
              {{- $twinPolicy = merge $twinPolicy (include "bb-common.network-policies.metadata-overrides" (list $localConfig $remoteConfig) | fromYaml) }}
              {{- $authzpols = append $authzpols $twinPolicy }}
            {{- end }}
          {{- else if eq $remoteType "cidr" }}
            {{- $authzPolicy := include "bb-common.istio.authorization-policies.generate.from-cidr-network-policy" $args | fromYaml }}
            {{- $authzPolicy := merge $authzPolicy (include "bb-common.network-policies.metadata-overrides" (list $localConfig $remoteConfig) | fromYaml) }}
            {{- $authzpols = append $authzpols $authzPolicy }}
          {{- else if eq $remoteType "definition" }}
            {{- $authzPolicy := include "bb-common.istio.authorization-policies.generate.from-definition" (list $ctx $netpol $remoteKey) | fromYaml }}
            {{- if $authzPolicy }}
              {{- $authzpols = append $authzpols $authzPolicy }}
            {{- end }}
          {{- end }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}

  {{- if eq (include "bb-common.network-policies.hbone-port-injection.enabled" $ctx) "true" }}
    {{- $netpols = include "bb-common.network-policies.inject-hbone-ports" (list $netpols "ingress") | fromYamlArray }}
  {{- end }}

  {{- if dig "ingress" "defaults" "enabled" true $ctx.Values.networkPolicies }} 
    {{- $netpols = concat $netpols (include "bb-common.network-policies.ingress.defaults.render" $ctx | fromYamlArray) }}
  {{- end }}

  {{- $netpols = include "bb-common.utils.dedupe" $netpols | fromYamlArray }}
  {{- $authzpols = include "bb-common.utils.dedupe" $authzpols | fromYamlArray }}

  {{- range $netpol := $netpols }}
    {{- print "---" | nindent 0 }}
    {{- $netpol | toYaml | nindent 0 }}
  {{- end }}
  
  {{- range $authzpol := $authzpols }}
    {{- print "---" | nindent 0 }}
    {{- $authzpol | toYaml | nindent 0 }}
  {{- end }}
{{- end }}
