{{- define "bb-common.network-policies.egress.defaults.render" }}
  {{- $ctx := . }}
  {{- $netpols := list }}

  {{- $egressDefaults := dig "egress" "defaults" dict $ctx.Values.networkPolicies }}

  {{- if dig "denyAll" "enabled" true $egressDefaults }}
    {{- $netpols = append $netpols (include "bb-common.network-policies.egress.defaults.deny-all" $ctx | fromYaml) }}
  {{- end }}
  {{- if dig "allowInNamespace" "enabled" true $egressDefaults }}
    {{- $netpols = append $netpols (include "bb-common.network-policies.egress.defaults.allow-all-in-ns" $ctx | fromYaml) }}
  {{- end }}
  {{- if dig "allowKubeDns" "enabled" true $egressDefaults }}
    {{- $netpols = append $netpols (include "bb-common.network-policies.egress.defaults.allow-kube-dns" $ctx | fromYaml) }}
  {{- end }}
  {{- /* Sidecars and waypoint proxies need egress to istiod (CA/xDS on 15012); plain
         ambient workloads use ztunnel and do not. Skip in ambient mode unless a
         waypoint is present (auto-created when a route enables authservice). */}}
  {{- $ambient := eq (include "bb-common.istio.ambient.enabled" $ctx) "true" }}
  {{- $waypointEnabled := eq (include "bb-common.istio.waypoint.enabled" $ctx) "true" }}
  {{- if and (dig "allowIstiod" "enabled" true $egressDefaults) (or (not $ambient) $waypointEnabled) }}
    {{- $netpols = append $netpols (include "bb-common.network-policies.egress.defaults.allow-istiod" $ctx | fromYaml) }}
  {{- end }}

  {{- if dig "defaultsAsHooks" "enabled" false $ctx.Values.networkPolicies }}
    {{- $defaultHooks := dig "defaultsAsHooks" dict $ctx.Values.networkPolicies }}
    {{- $defaultHookTypes := list "pre-install" "pre-upgrade" "post-delete" }}
    {{- $defaultWeight := -5 }}
    {{- $defaultDeletePolicies := list "hook-succeeded" "before-hook-creation" }}

    {{- $hooks := dig "hooks" $defaultHookTypes $defaultHooks }}
    {{- $weight := dig "weight" $defaultWeight $defaultHooks }}
    {{- $deletePolicies := dig "deletePolicies" $defaultDeletePolicies $defaultHooks }}

    {{- $netpols = concat $netpols ((include "bb-common.utils.as-hooks" (list $netpols $hooks $weight $deletePolicies)) | fromYamlArray) }}
  {{- end }}

  {{- $netpols | toYaml }}
{{- end }}
