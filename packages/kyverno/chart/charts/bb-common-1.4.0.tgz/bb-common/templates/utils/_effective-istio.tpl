{{- /*
Effective (resolved) Istio settings.

These helpers answer "is X actually in effect?" after defaults and cross-setting
rules are applied, as opposed to the raw declared values — e.g. ambient mode
forces sidecar off and authorization policies on regardless of what was declared.
Every template that needs one of these answers MUST go through these helpers so
all feature areas agree in the interaction cases.

Routes-derived effective values live in _effective-routes.tpl.
*/ -}}

{{- define "bb-common.istio.ambient.enabled" -}}
{{- $istio := .Values.istio | default dict -}}
{{- dig "ambient" "enabled" false $istio -}}
{{- end -}}

{{- /* True only when an ambient waypoint Gateway is auto-created: ambient mode is on and at
       least one inbound route enables authservice (ext_authz needs an L7 waypoint). There is
       no istio.waypoint values key — this is derived entirely from
       "bb-common.routes.authservice.enabled" (see _effective-routes.tpl). */ -}}
{{- define "bb-common.istio.waypoint.enabled" -}}
{{- if and (eq (include "bb-common.istio.ambient.enabled" .) "true") (eq (include "bb-common.routes.authservice.enabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- /* Effective waypoint Gateway name (release-name-prefixed to match the rendered Gateway / its
       gateway.networking.k8s.io/gateway-name pod label). The waypoint is bb-common-managed, so
       the name is fixed rather than configurable. */ -}}
{{- define "bb-common.istio.waypoint.name" -}}
{{- $ctx := . -}}
{{- include "bb-common.prepend-release-name" (list $ctx "waypoint" "istio") | trim -}}
{{- end -}}

{{- define "bb-common.istio.sidecar.enabled" -}}
{{- if eq (include "bb-common.istio.ambient.enabled" .) "true" -}}
false
{{- else -}}
{{- $istio := .Values.istio | default dict -}}
{{- dig "sidecar" "enabled" false $istio -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.istio.authorization-policies.enabled" -}}
{{- $ctx := . -}}
{{- $default := false -}}
{{- if kindIs "slice" . -}}
{{- $ctx = index . 0 -}}
{{- $default = index . 1 -}}
{{- end -}}
{{- if eq (include "bb-common.istio.ambient.enabled" $ctx) "true" -}}
true
{{- else -}}
{{- $istio := $ctx.Values.istio | default dict -}}
{{- dig "authorizationPolicies" "enabled" $default $istio -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.istio.authorization-policies.generate-from-netpol.enabled" -}}
{{- $ctx := . -}}
{{- $default := false -}}
{{- if kindIs "slice" . -}}
{{- $ctx = index . 0 -}}
{{- $default = index . 1 -}}
{{- end -}}
{{- if eq (include "bb-common.istio.ambient.enabled" $ctx) "true" -}}
true
{{- else -}}
{{- $istio := $ctx.Values.istio | default dict -}}
{{- dig "authorizationPolicies" "generateFromNetpol" $default $istio -}}
{{- end -}}
{{- end -}}

{{- /* networkPolicies-domain setting, but derived from ambient mode, so it lives with
       the istio effective values. */ -}}
{{- define "bb-common.network-policies.hbone-port-injection.enabled" -}}
{{- if eq (include "bb-common.istio.ambient.enabled" .) "true" -}}
true
{{- else -}}
{{- $networkPolicies := .Values.networkPolicies | default dict -}}
{{- dig "hbonePortInjection" "enabled" false $networkPolicies -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.warn.ambient" -}}
{{- $istio := .Values.istio | default dict -}}
{{- if and (eq (include "bb-common.istio.ambient.enabled" .) "true") (dig "sidecar" "enabled" false $istio) -}}
# WARNING: istio.ambient.enabled=true ignores istio.sidecar.enabled=true. Ambient mode does not render Istio Sidecar resources.
{{- end -}}
{{- end -}}
