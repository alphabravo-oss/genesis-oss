{{- /*
Authservice resource builder.

Builds the RequestAuthentication (OIDC JWT validation) + CUSTOM AuthorizationPolicy
(ext_authz to the authservice provider) pair from an already-resolved binding for
the per-route `routes.inbound.<name>.authservice` hook (see _render.tpl). Kept as a
separate builder so binding resolution and resource shape stay decoupled.

The ext_authz provider is the fixed convention "authservice" (the extensionProviders
entry the Big Bang authservice package registers in the mesh config). It is
deliberately NOT configurable for now — the whole authservice contract (provider
name here, Service namespace/name/port in _egress-netpol.tpl) is hardcoded as one
piece; follow-up work can make it configurable together.

Args (list):
  0 ctx       - root context
  1 name      - metadata.name for both resources
  2 issuer    - OIDC issuer (required, validated by the caller)
  3 clientId  - OIDC client id (used as the JWT audience; validated by the caller)
  4 jwksUri   - JWKS URI; derived from issuer when empty
  5 binding   - dict with either `targetRefs` (ambient) or `selector` (sidecar)
  6 rules     - CUSTOM AuthorizationPolicy rules list; the caller passes
                unauthenticated-only rules (no Authorization header), host-scoped
                to the route's gateways when authservice.ingressOnly is set
  7 denyRules - DENY AuthorizationPolicy rules list (jwt enforcement backstop,
                equivalent of the authservice package's jwt-authz policy)
  8 routeMeta - the route's `metadata` dict; its labels/annotations are applied
                to all three resources, like every other route-generated resource

Returns a YAML array of [RequestAuthentication, AuthorizationPolicy (CUSTOM),
AuthorizationPolicy (DENY)].
*/}}
{{- define "bb-common.routes.inbound.authservice.policies" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $issuer := index . 2 }}
  {{- $clientId := index . 3 }}
  {{- $jwksUri := index . 4 }}
  {{- $binding := index . 5 }}
  {{- $rules := index . 6 }}
  {{- $denyRules := index . 7 }}
  {{- $routeMeta := index . 8 }}
  {{- $resources := list }}

  {{- if not $jwksUri }}
    {{- $jwksUri = printf "%s/protocol/openid-connect/certs" (trimSuffix "/" $issuer) }}
  {{- end }}

  {{- $labels := dict }}
  {{- $annotations := dict }}
  {{- if $routeMeta }}
    {{- $labels = $routeMeta.labels | default dict }}
    {{- $annotations = $routeMeta.annotations | default dict }}
  {{- end }}

  {{- /* RequestAuthentication */}}
  {{- $requestAuth := dict "apiVersion" "security.istio.io/v1" "kind" "RequestAuthentication" }}
  {{- $raMetadata := dict "name" $name "namespace" $ctx.Release.Namespace }}
  {{- if $labels }}
    {{- $_ := set $raMetadata "labels" $labels }}
  {{- end }}
  {{- if $annotations }}
    {{- $_ := set $raMetadata "annotations" $annotations }}
  {{- end }}
  {{- $_ := set $requestAuth "metadata" $raMetadata }}
  {{- $jwtRule := dict "issuer" $issuer "audiences" (list $clientId) "jwksUri" $jwksUri "forwardOriginalToken" true }}
  {{- $raSpec := dict "jwtRules" (list $jwtRule) }}
  {{- range $k, $v := $binding }}
    {{- $_ := set $raSpec $k $v }}
  {{- end }}
  {{- $_ := set $requestAuth "spec" $raSpec }}
  {{- $resources = append $resources $requestAuth }}

  {{- /* CUSTOM AuthorizationPolicy (ext_authz to the fixed "authservice" provider) */}}
  {{- $authzPolicy := dict "apiVersion" "security.istio.io/v1" "kind" "AuthorizationPolicy" }}
  {{- $apMetadata := dict "name" $name "namespace" $ctx.Release.Namespace }}
  {{- if $labels }}
    {{- $_ := set $apMetadata "labels" $labels }}
  {{- end }}
  {{- if $annotations }}
    {{- $_ := set $apMetadata "annotations" $annotations }}
  {{- end }}
  {{- $_ := set $authzPolicy "metadata" $apMetadata }}
  {{- $apSpec := dict "action" "CUSTOM" "provider" (dict "name" "authservice") "rules" $rules }}
  {{- range $k, $v := $binding }}
    {{- $_ := set $apSpec $k $v }}
  {{- end }}
  {{- $_ := set $authzPolicy "spec" $apSpec }}
  {{- $resources = append $resources $authzPolicy }}

  {{- /* DENY AuthorizationPolicy (jwt enforcement backstop). DENY is evaluated
         before ALLOW, so the route's gateway ALLOW policy cannot admit a request
         this rejects — requests without a validated request principal from the
         issuer never reach the workload even if ext_authz is bypassed. */}}
  {{- $denyPolicy := dict "apiVersion" "security.istio.io/v1" "kind" "AuthorizationPolicy" }}
  {{- $denyMetadata := dict "name" (printf "%s-jwt-deny" $name) "namespace" $ctx.Release.Namespace }}
  {{- if $labels }}
    {{- $_ := set $denyMetadata "labels" $labels }}
  {{- end }}
  {{- if $annotations }}
    {{- $_ := set $denyMetadata "annotations" $annotations }}
  {{- end }}
  {{- $_ := set $denyPolicy "metadata" $denyMetadata }}
  {{- $denySpec := dict "action" "DENY" "rules" $denyRules }}
  {{- range $k, $v := $binding }}
    {{- $_ := set $denySpec $k $v }}
  {{- end }}
  {{- $_ := set $denyPolicy "spec" $denySpec }}
  {{- $resources = append $resources $denyPolicy }}

  {{- $resources | toYaml }}
{{- end }}
