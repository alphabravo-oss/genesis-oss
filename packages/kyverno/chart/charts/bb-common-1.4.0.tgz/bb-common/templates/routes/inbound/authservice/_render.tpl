{{- /*
Per-route authservice (OIDC ext_authz) policy generation.

When an inbound route sets `authservice.enabled: true`, emit a RequestAuthentication
+ CUSTOM AuthorizationPolicy + jwt DENY backstop for it, reusing the route's own
`service`/`selector` for binding and the same waypoint-aware enforcement-point logic
as the route's AuthorizationPolicy:

  - ambient -> targetRefs Service/<route.service> (enforced at the shared waypoint
    bb-common auto-creates for authservice, alongside the namespace-wide deny-all)
  - sidecar -> selector.matchLabels: <route.selector>

In ambient mode an intra-namespace ALLOW policy
(`<route>-authservice-allow-in-ns`) is emitted alongside. The waypoint only
evaluates policies bound with targetRefs, so the namespace allow-all default
(which ztunnel enforces) has to be restated there; without it the gateway
ALLOW policy would deny every in-mesh caller.

Resources are named `<route>-authservice[-jwt-deny|-allow-in-ns]`, so multiple
protected routes coexist. This hook does not set the istio.io/ingress-use-waypoint
enrollment label (owned by the consuming package).
*/}}
{{- define "bb-common.routes.inbound.authservice" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}
  {{- $resources := list }}
  {{- $as := $route.authservice | default dict }}

  {{- if dig "enabled" false $as }}
    {{- $issuer := $as.issuer | default "" }}
    {{- $clientId := $as.clientId | default "" }}
    {{- if not $issuer }}
      {{- fail (printf "routes.inbound.%s.authservice.issuer is required when enabled" $name) }}
    {{- end }}
    {{- if not $clientId }}
      {{- fail (printf "routes.inbound.%s.authservice.clientId is required when enabled" $name) }}
    {{- end }}

    {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "%s-authservice" $name) "routes") | trim }}

    {{- /* Binding derived from the route. In ambient mode enabling authservice
           auto-creates the shared waypoint, so ext_authz always targets the Service
           (enforced at that waypoint); sidecar mode binds by workload selector. */}}
    {{- $binding := dict }}
    {{- if eq (include "bb-common.istio.ambient.enabled" $ctx) "true" }}
      {{- /* route.service may be a template string and/or an FQDN; targetRefs wants
             the local Service name */}}
      {{- $serviceName := tpl (default $name $route.service) $ctx | splitList "." | first }}
      {{- $_ := set $binding "targetRefs" (list (dict "group" "" "kind" "Service" "name" $serviceName)) }}
    {{- else }}
      {{- $_ := set $binding "selector" (dict "matchLabels" $route.selector) }}
    {{- end }}

    {{- /* rules: only requests WITHOUT an Authorization header go to authservice
           (the browser login flow). Token-bearing requests skip ext_authz and are
           checked by the RequestAuthentication + jwt DENY instead, so programmatic
           clients with a valid JWT don't get login redirects.

           denyRules: the jwt enforcement backstop (bb-common's equivalent of the
           authservice package's jwt-authz policy, inverted to a DENY so the route's
           gateway ALLOW policy cannot OR around it) — deny requests that lack a
           validated request principal from the issuer.

           ingressOnly scopes both to traffic arriving via the route's gateway(s),
           so in-mesh clients are never sent to the provider (no OIDC redirects) and
           are exempt from the JWT requirement. Default is unscoped. */}}
    {{- $unauthenticatedWhen := list (dict "key" "request.headers[authorization]" "notValues" (list "*")) }}
    {{- $jwtPrincipal := printf "%s/*" (trimSuffix "/" $issuer) }}
    {{- $rules := list (dict "when" $unauthenticatedWhen) }}
    {{- $denyRules := list (dict "from" (list (dict "source" (dict "notRequestPrincipals" (list $jwtPrincipal))))) }}
    {{- if dig "ingressOnly" false $as }}
      {{- /* Istio forbids identity-based from.source fields (principals,
             namespaces, ...) with CUSTOM action, so the ext_authz policy is scoped
             by the route's public hostnames instead: ingress traffic addresses the
             external host; in-mesh traffic addresses the cluster-local Service DNS
             name and never matches. Both host and host:* forms are listed since
             :authority may carry a port. The DENY keeps identity scoping (gateway
             namespace + service-account principal, same derivation as
             _authz.tpl). */}}
      {{- $hosts := list }}
      {{- range $host := $route.hosts }}
        {{- $resolvedHost := tpl $host $ctx }}
        {{- $hosts = append $hosts $resolvedHost }}
        {{- $hosts = append $hosts (printf "%s:*" $resolvedHost) }}
      {{- end }}
      {{- $denyFroms := list }}
      {{- range $gateway := $route.gateways }}
        {{- $gatewayParts := split "/" $gateway }}
        {{- $gatewayNamespaces := list $gatewayParts._0 }}
        {{- $gatewayPrincipals := list (printf "cluster.local/ns/%s/sa/%s-ingressgateway-service-account" $gatewayParts._0 $gatewayParts._1) }}
        {{- $denyFroms = append $denyFroms (dict "source" (dict "namespaces" $gatewayNamespaces "principals" $gatewayPrincipals "notRequestPrincipals" (list $jwtPrincipal))) }}
      {{- end }}
      {{- $rules = list (dict "to" (list (dict "operation" (dict "hosts" $hosts))) "when" $unauthenticatedWhen) }}
      {{- $denyRules = list (dict "from" $denyFroms) }}
    {{- end }}

    {{- $resources = include "bb-common.routes.inbound.authservice.policies" (list $ctx $resourceName $issuer $clientId ($as.jwksUri | default "") $binding $rules $denyRules ($route.metadata | default dict)) | fromYamlArray }}

    {{- /* The gateway ALLOW policy above is waypoint-bound, and a waypoint only
           evaluates policies bound with targetRefs. The namespace allow-all
           default is enforced by ztunnel, never at the waypoint, so on its own
           the gateway ALLOW would deny every in-mesh caller. Restate the
           namespace default at the waypoint, gated on the same allowInNamespace
           toggle. This doesn't weaken anything: the ext_authz and jwt DENY
           policies run before ALLOW and still apply (with ingressOnly, in-mesh
           callers are exempt from those by design). */}}
    {{- if and (eq (include "bb-common.istio.ambient.enabled" $ctx) "true") (eq (include "bb-common.istio.authorization-policies.defaults.allow-in-namespace-enabled" $ctx) "true") }}
      {{- $allowPolicy := dict "apiVersion" "security.istio.io/v1" "kind" "AuthorizationPolicy" }}
      {{- $allowMetadata := dict "name" (printf "%s-allow-in-ns" $resourceName) "namespace" $ctx.Release.Namespace }}
      {{- if $route.metadata }}
        {{- with $route.metadata.labels }}
          {{- $_ := set $allowMetadata "labels" . }}
        {{- end }}
        {{- with $route.metadata.annotations }}
          {{- $_ := set $allowMetadata "annotations" . }}
        {{- end }}
      {{- end }}
      {{- $_ := set $allowPolicy "metadata" $allowMetadata }}
      {{- $allowSpec := dict "action" "ALLOW" "rules" (list (dict "from" (list (dict "source" (dict "namespaces" (list $ctx.Release.Namespace)))))) }}
      {{- range $k, $v := $binding }}
        {{- $_ := set $allowSpec $k $v }}
      {{- end }}
      {{- $_ := set $allowPolicy "spec" $allowSpec }}
      {{- $resources = append $resources $allowPolicy }}
    {{- end }}
  {{- end }}

  {{- $resources | toYaml }}
{{- end }}
