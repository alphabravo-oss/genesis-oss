{{- /*
Egress NetworkPolicy: shared waypoint pod -> authservice ext_authz.

For an authservice-protected route in ambient mode, the WAYPOINT pod (not the
application workload) makes the ext_authz gRPC call while mediating the route's
traffic. The route's workload-scoped egress policies never select the waypoint pod,
so the call is dropped and the OIDC login flow fails. This emits the missing
allowance, from the waypoint pod (gateway.networking.k8s.io/gateway-name label) to
the authservice Service.

The target is the fixed Big Bang contract authservice/authservice:10003
(namespace/Service:port), matching the fixed "authservice" ext_authz provider in
_policies.tpl — deliberately not configurable for now. Port 15008 (HBONE) is also
opened since authservice is itself ambient-enrolled, mirroring the k8s shorthand's
HBONE injection.
*/}}
{{- define "bb-common.routes.inbound.authservice-egress-netpol" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- $svcNamespace := "authservice" }}
  {{- $svcName := "authservice" }}
  {{- $svcPort := 10003 }}
  {{- $waypointName := include "bb-common.istio.waypoint.name" $ctx }}

  {{- $netpol := dict }}
  {{- $_ := set $netpol "apiVersion" "networking.k8s.io/v1" }}
  {{- $_ := set $netpol "kind" "NetworkPolicy" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "allow-egress-from-%s-waypoint-to-authservice-tcp-port-%d" $name $svcPort) "routes") | trim }}
  {{- $metadata := dict "name" $resourceName "namespace" $ctx.Release.Namespace }}
  {{- if $route.metadata }}
    {{- if $route.metadata.labels }}
      {{- $_ := set $metadata "labels" $route.metadata.labels }}
    {{- end }}
    {{- if $route.metadata.annotations }}
      {{- $_ := set $metadata "annotations" $route.metadata.annotations }}
    {{- end }}
  {{- end }}
  {{- $_ := set $netpol "metadata" $metadata }}

  {{- $spec := dict }}
  {{- $_ := set $spec "podSelector" (dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" $waypointName)) }}
  {{- $_ := set $spec "policyTypes" (list "Egress") }}

  {{- $namespaceSelector := dict "matchLabels" (dict "kubernetes.io/metadata.name" $svcNamespace) }}
  {{- $podSelector := dict "matchLabels" (dict "app.kubernetes.io/name" $svcName) }}
  {{- $to := dict "namespaceSelector" $namespaceSelector "podSelector" $podSelector }}
  {{- $ports := list (dict "port" $svcPort "protocol" "TCP") (dict "port" 15008 "protocol" "TCP") }}
  {{- $egress := dict "to" (list $to) "ports" $ports }}
  {{- $_ := set $spec "egress" (list $egress) }}

  {{- $_ := set $netpol "spec" $spec }}

  {{- $netpol | toYaml }}
{{- end }}
