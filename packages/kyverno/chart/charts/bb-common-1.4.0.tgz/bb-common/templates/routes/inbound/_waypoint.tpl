{{- /*
Shared ambient waypoint Gateway, auto-created when any inbound route sets
`authservice.enabled: true` in ambient mode (OIDC ext_authz is enforced at an L7
waypoint). There is no separate waypoint values key — the waypoint exists because
authservice needs it.

Labeled `istio.io/waypoint-for: service` (the traffic type it handles). Enrolling
Services / the namespace onto it (`istio.io/use-waypoint` /
`istio.io/ingress-use-waypoint`) is owned by the consuming package.
*/}}
{{- define "bb-common.routes.inbound.waypoint" }}
  {{- $ctx := index . 0 }}

  {{- $waypointResource := dict "apiVersion" "gateway.networking.k8s.io/v1" "kind" "Gateway" }}
  {{- $name := include "bb-common.istio.waypoint.name" $ctx }}
  {{- $labels := dict "istio.io/waypoint-for" "service" }}
  {{- $metadata := dict "name" $name "namespace" $ctx.Release.Namespace "labels" $labels }}
  {{- $_ := set $waypointResource "metadata" $metadata }}

  {{- $listener := dict "name" "mesh" "port" 15008 "protocol" "HBONE" }}
  {{- $_ := set $waypointResource "spec" (dict "gatewayClassName" "istio-waypoint" "listeners" (list $listener)) }}

  {{- $waypointResource | toYaml }}
{{- end }}
