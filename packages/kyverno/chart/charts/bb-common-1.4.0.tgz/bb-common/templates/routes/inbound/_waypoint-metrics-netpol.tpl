{{- /*
Lets prometheus scrape the shared waypoint pod.

The waypoint's istio-proxy serves metrics on 15020. In sidecar mode the
allow-prometheus-to-istio-sidecar default covers this, but that default is
skipped in ambient mode, so without this policy the namespace deny-all drops
the scrape and the waypoint's prometheus targets go down.

Emitted once alongside the waypoint Gateway and shared by all protected
routes, so it carries no single route's metadata. Gated on
networkPolicies.ingress.defaults.enabled, like the sidecar default it stands
in for.
*/}}
{{- define "bb-common.routes.inbound.waypoint-metrics-netpol" }}
  {{- $ctx := index . 0 }}
  {{- $waypointName := include "bb-common.istio.waypoint.name" $ctx }}

  {{- $netpol := dict }}
  {{- $_ := set $netpol "apiVersion" "networking.k8s.io/v1" }}
  {{- $_ := set $netpol "kind" "NetworkPolicy" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx "allow-ingress-to-waypoint-tcp-port-15020-from-ns-monitoring-pod-prometheus" "routes") | trim }}
  {{- $_ := set $netpol "metadata" (dict "name" $resourceName "namespace" $ctx.Release.Namespace) }}

  {{- $spec := dict }}
  {{- $_ := set $spec "podSelector" (dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" $waypointName)) }}
  {{- $_ := set $spec "policyTypes" (list "Ingress") }}

  {{- $namespaceSelector := dict "matchLabels" (dict "kubernetes.io/metadata.name" "monitoring") }}
  {{- $podSelector := dict "matchLabels" (dict "app.kubernetes.io/name" "prometheus") }}
  {{- $from := dict "namespaceSelector" $namespaceSelector "podSelector" $podSelector }}
  {{- $ingress := dict "from" (list $from) "ports" (list (dict "port" 15020 "protocol" "TCP")) }}
  {{- $_ := set $spec "ingress" (list $ingress) }}

  {{- $_ := set $netpol "spec" $spec }}

  {{- $netpol | toYaml }}
{{- end }}
