{{- define "bb-common.extra-objects.render" }}
  {{- $ctx := . }}
  {{- $resources := $ctx.Values.extraObjects | default list }}
  {{- if kindIs "map" $resources }}
    {{- $ordered := list }}
    {{- range $key := keys $resources | sortAlpha }}
      {{- $ordered = append $ordered (index $resources $key) }}
    {{- end }}
    {{- $resources = $ordered }}
  {{- end }}
  {{- range $resource := $resources }}
    {{- $resource = deepCopy $resource }}
    {{- $metadata := $resource.metadata | default dict }}
    {{- $labels := merge (dict "extra-objects.bigbang.dev/source" "bb-common") ($metadata.labels | default dict) }}
    {{- $_ := set $metadata "labels" $labels }}
    {{- $_ := set $resource "metadata" $metadata }}
    {{- print "---" | nindent 0 }}
    {{- tpl (toYaml $resource) $ctx | nindent 0 }}
  {{- end }}
{{- end }}
