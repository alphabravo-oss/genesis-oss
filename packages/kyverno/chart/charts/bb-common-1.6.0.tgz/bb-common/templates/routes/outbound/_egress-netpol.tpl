{{- /*
Allows HBONE egress (15008) from this namespace to the egress waypoint's pods.
Emitted once per distinct waypoint, not per route.
*/}}
{{- define "bb-common.routes.outbound.egress-netpol" }}
  {{- $ctx := index . 0 }}
  {{- $egressGateway := index . 1 }}

  {{- $waypoint := splitList "/" $egressGateway }}
  {{- $waypointNamespace := first $waypoint }}
  {{- $waypointName := last $waypoint }}

  {{- $netpol := dict }}
  {{- $_ := set $netpol "apiVersion" "networking.k8s.io/v1" }}
  {{- $_ := set $netpol "kind" "NetworkPolicy" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "allow-egress-to-%s-%s" $waypointNamespace $waypointName) "routes") | trim }}
  {{- $_ := set $netpol "metadata" (dict "name" $resourceName "namespace" $ctx.Release.Namespace) }}

  {{- $spec := dict }}
  {{- $_ := set $spec "podSelector" dict }}
  {{- $_ := set $spec "policyTypes" (list "Egress") }}

  {{- $namespaceSelector := dict "matchLabels" (dict "kubernetes.io/metadata.name" $waypointNamespace) }}
  {{- $podSelector := dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" $waypointName) }}
  {{- $to := dict "namespaceSelector" $namespaceSelector "podSelector" $podSelector }}
  {{- $egress := dict "to" (list $to) "ports" (list (dict "port" 15008 "protocol" "TCP")) }}
  {{- $_ := set $spec "egress" (list $egress) }}

  {{- $_ := set $netpol "spec" $spec }}
  {{- $netpol | toYaml }}
{{- end }}
