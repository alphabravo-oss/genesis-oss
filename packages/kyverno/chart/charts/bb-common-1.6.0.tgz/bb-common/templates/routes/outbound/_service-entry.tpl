{{- /* Resolved ServiceEntry ports for an outbound route (templated numbers
       expanded, defaulting to 443/HTTPS). Shared by the ServiceEntry and the
       egress-waypoint AuthorizationPolicy. Args: [ctx, route] */}}
{{- define "bb-common.routes.outbound.ports" }}
  {{- $ctx := index . 0 }}
  {{- $route := index . 1 }}

  {{- $ports := list }}
  {{- range $port := $route.ports }}
    {{- $portNumber := $port.number }}
    {{- if kindIs "string" $portNumber }}
      {{- $portNumber = tpl $portNumber $ctx | int }}
    {{- end }}

    {{- $port := dict
      "name" $port.name
      "number" $portNumber
      "protocol" $port.protocol
    }}

    {{- $ports = append $ports $port }}
  {{- end }}

  {{- if not $ports }}
    {{- $httpsPort := dict
      "name" "https"
      "number" 443
      "protocol" "HTTPS"
    }}
    {{- $ports = append $ports $httpsPort }}
  {{- end }}

  {{- $ports | toYaml }}
{{- end }}

{{- /* Name of the generated ServiceEntry; also referenced by the egress
       AuthorizationPolicy's targetRefs. Args: [ctx, routeName, route] */ -}}
{{- define "bb-common.routes.outbound.service-entry-name" -}}
{{- $ctx := index . 0 -}}
{{- $name := index . 1 -}}
{{- $route := index . 2 -}}
{{- $location := $route.location | default "MESH_EXTERNAL" -}}
{{- $resourceName := printf "%s-%s" $name (ternary "external" "internal" (eq $location "MESH_EXTERNAL")) -}}
{{- include "bb-common.prepend-release-name" (list $ctx $resourceName "routes") | trim -}}
{{- end -}}

{{- define "bb-common.routes.outbound.service-entry" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- if not $route.hosts }}
    {{- fail (printf "Route '%s' must define at least one host for outbound ServiceEntry" $name) }}
  {{- end }}

  {{- $hosts := list }}
  {{- range $host := $route.hosts }}
    {{- $hosts = append $hosts (tpl $host $ctx) }}
  {{- end }}

  {{- $ports := include "bb-common.routes.outbound.ports" (list $ctx $route) | fromYamlArray }}

  {{- $location := $route.location | default "MESH_EXTERNAL" }}
  {{- $resolution := $route.resolution | default "DNS" }}
  {{- $exportTo := $route.exportTo | default (list ".") }}

  {{- $spec := dict 
    "hosts" $hosts
    "exportTo" $exportTo
    "location" $location
    "resolution" $resolution
    "ports" $ports
  }}

  {{- $labels := dig "metadata" "labels" dict $route }}
  {{- $annotations := dig "metadata" "annotations" dict $route }}

  {{- $_ := set $labels "service-entries.bigbang.dev/source" "bb-common" }}
  {{- $_ := set $annotations "outbound.service-entries.generated.bigbang.dev/from-route-name" $name }}

  {{- /* egressGateway is the resolved "<namespace>/<name>" value */}}
  {{- if $route.egressGateway }}
    {{- $waypoint := splitList "/" $route.egressGateway }}
    {{- $_ := set $labels "istio.io/use-waypoint" (last $waypoint) }}
    {{- $_ := set $labels "istio.io/use-waypoint-namespace" (first $waypoint) }}
  {{- end }}

  {{- $resourceName := include "bb-common.routes.outbound.service-entry-name" (list $ctx $name $route) }}

  {{- $metadata := dict
    "labels" $labels
    "annotations" $annotations
    "name" $resourceName
    "namespace" $ctx.Release.Namespace
  }}

  {{- $serviceEntry := dict
    "apiVersion" "networking.istio.io/v1"
    "kind" "ServiceEntry"
    "metadata" $metadata
    "spec" $spec
  }}

  {{- $serviceEntry | toYaml }}
{{- end }}
