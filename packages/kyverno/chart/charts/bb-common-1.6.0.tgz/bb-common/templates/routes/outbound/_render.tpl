{{- define "bb-common.routes.outbound.render" }}
  {{- $ctx := . }}
  {{- include "bb-common.warn.egress-gateway" $ctx }}
  {{- $resources := list }}
  {{- $istioAvailable := $ctx.Capabilities.APIVersions.Has "networking.istio.io/v1" }}

  {{- if and $istioAvailable $ctx.Values.routes $ctx.Values.routes.outbound }}
    {{- $netpolEnabled := dig "enabled" false ($ctx.Values.networkPolicies | default dict) }}
    {{- range $name, $route := $ctx.Values.routes.outbound }}
      {{- if not $route.enabled }}
        {{- continue }}
      {{- end }}

      {{- $egressGateway := include "bb-common.routes.outbound.egress-gateway" (list $ctx $route) }}
      {{- $route = mergeOverwrite (deepCopy $route) (dict "egressGateway" $egressGateway) }}

      {{- $serviceEntry := include "bb-common.routes.outbound.service-entry" (list $ctx $name $route) | fromYaml }}
      {{- $resources = append $resources $serviceEntry }}

      {{- /* Waypoint-bound routes need an ALLOW policy at the waypoint (its
             baseline is default-deny) and HBONE egress to reach it. Identical
             per-waypoint netpols collapse in the dedupe pass. */}}
      {{- if $egressGateway }}
        {{- $authz := include "bb-common.routes.outbound.authz" (list $ctx $name $route) | fromYaml }}
        {{- $resources = append $resources $authz }}

        {{- if $netpolEnabled }}
          {{- $netpol := include "bb-common.routes.outbound.egress-netpol" (list $ctx $egressGateway) | fromYaml }}
          {{- $resources = append $resources $netpol }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}

  {{- $resources = include "bb-common.utils.dedupe" $resources | fromYamlArray }}

  {{- range $resource := $resources }}
    {{- print "---" | nindent 0 }}
    {{- $resource | toYaml | nindent 0 }}
  {{- end }}
{{- end }}

