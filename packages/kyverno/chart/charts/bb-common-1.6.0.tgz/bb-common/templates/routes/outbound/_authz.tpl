{{- /*
Admits an outbound route's traffic at its egress waypoint (whose baseline is
default-deny). targetRefs scopes enforcement to the route's ServiceEntry;
rules constrain sources to this namespace and the route's ports.
*/}}
{{- define "bb-common.routes.outbound.authz" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- $serviceEntryName := include "bb-common.routes.outbound.service-entry-name" (list $ctx $name $route) }}

  {{- $ports := include "bb-common.routes.outbound.ports" (list $ctx $route) | fromYamlArray }}
  {{- $portStrings := list }}
  {{- range $port := $ports }}
    {{- $portStrings = append $portStrings (toString $port.number) }}
  {{- end }}

  {{- $authz := dict }}
  {{- $_ := set $authz "apiVersion" "security.istio.io/v1" }}
  {{- $_ := set $authz "kind" "AuthorizationPolicy" }}

  {{- $metadata := dict "name" (printf "%s-egress" $serviceEntryName) "namespace" $ctx.Release.Namespace }}
  {{- if $route.metadata }}
    {{- if $route.metadata.labels }}
      {{- $_ := set $metadata "labels" $route.metadata.labels }}
    {{- end }}
    {{- if $route.metadata.annotations }}
      {{- $_ := set $metadata "annotations" $route.metadata.annotations }}
    {{- end }}
  {{- end }}
  {{- $_ := set $authz "metadata" $metadata }}

  {{- $spec := dict }}
  {{- $_ := set $spec "targetRefs" (list (dict "group" "networking.istio.io" "kind" "ServiceEntry" "name" $serviceEntryName)) }}
  {{- $_ := set $spec "action" "ALLOW" }}

  {{- $rule := dict }}
  {{- $_ := set $rule "from" (list (dict "source" (dict "namespaces" (list $ctx.Release.Namespace)))) }}
  {{- $_ := set $rule "to" (list (dict "operation" (dict "ports" $portStrings))) }}
  {{- $_ := set $spec "rules" (list $rule) }}

  {{- $_ := set $authz "spec" $spec }}
  {{- $authz | toYaml }}
{{- end }}
