{{- /*
Effective (resolved) settings derived from the routes configuration.

Istio-domain effective values live in _effective-istio.tpl; note that
"bb-common.istio.waypoint.enabled" there is derived from the helper below.
*/ -}}

{{- /* True when any enabled inbound route enables authservice (OIDC ext_authz), which is
       what drives auto-creation of the shared ambient waypoint. */ -}}
{{- define "bb-common.routes.authservice.enabled" -}}
{{- $ctx := . -}}
{{- $found := false -}}
{{- $inbound := dig "inbound" dict ($ctx.Values.routes | default dict) -}}
{{- range $name, $route := $inbound -}}
{{- if and (dig "enabled" false $route) (dig "authservice" "enabled" false $route) -}}
{{- $found = true -}}
{{- end -}}
{{- end -}}
{{- $found -}}
{{- end -}}

{{- /*
Resolved egress gateway (waypoint) for an outbound route: the per-route
egressGateway when the key is present, else routes.defaults.outbound.egressGateway.
`false` at either level turns the feature off. Returns "<namespace>/<name>" or ""
when no waypoint applies.

Args: [ctx, route]
*/ -}}
{{- define "bb-common.routes.outbound.egress-gateway" -}}
{{- $ctx := index . 0 -}}
{{- $route := index . 1 -}}
{{- $gateway := dig "defaults" "outbound" "egressGateway" false ($ctx.Values.routes | default dict) -}}
{{- if hasKey $route "egressGateway" -}}
{{- $gateway = $route.egressGateway -}}
{{- end -}}
{{- if $gateway -}}
{{- if not (kindIs "string" $gateway) -}}
{{- fail (printf "routes.outbound: egressGateway must be \"<namespace>/<name>\" or false, got: %v" $gateway) -}}
{{- end -}}
{{- $gateway = tpl $gateway $ctx -}}
{{- $parts := splitList "/" $gateway -}}
{{- if or (ne (len $parts) 2) (not (first $parts)) (not (last $parts)) -}}
{{- fail (printf "routes.outbound: egressGateway '%s' is not in '<namespace>/<name>' format" $gateway) -}}
{{- end -}}
{{- $gateway -}}
{{- end -}}
{{- end -}}

{{- /* Waypoint bindings only take effect in ambient mode; warn rather than fail
       because the rendered resources are inert and the umbrella owns ambient gating. */ -}}
{{- define "bb-common.warn.egress-gateway" -}}
{{- $ctx := . -}}
{{- if ne (include "bb-common.istio.ambient.enabled" $ctx) "true" -}}
{{- $bound := list -}}
{{- range $name, $route := dig "outbound" dict ($ctx.Values.routes | default dict) -}}
{{- if and $route.enabled (include "bb-common.routes.outbound.egress-gateway" (list $ctx $route)) -}}
{{- $bound = append $bound $name -}}
{{- end -}}
{{- end -}}
{{- if $bound -}}
# WARNING: outbound route(s) {{ join ", " $bound }} configure egressGateway but istio.ambient.enabled=false. Waypoint bindings are ignored outside ambient mode; sidecar egress relies on REGISTRY_ONLY.
{{- end -}}
{{- end -}}
{{- end -}}

{{- /*
Find the authservice-protected inbound route that fronts the same workload as
an ingress netpol entry.

When a route enables authservice in ambient mode, its Service is enrolled on
the waypoint, so traffic from the entry's declared clients lands on the
waypoint pod instead of the workload. The ingress render uses this match to
mirror those client allowances onto the waypoint.

The match is by convention: the entry's pod selector must equal the route's
selector, and the entry's ports must include the route's workload port
(containerPort, falling back to port). Entries with matchExpressions, wildcard
local keys, or no ports are skipped.

Args: [ctx, podSelector (netpol spec.podSelector), ports (list)]
Returns a dict with route (name), service (local Service name), and port (the
Service port, as a string), or nothing when no route matches. Fails when the
entry matches routes that resolve to different services.
*/ -}}
{{- define "bb-common.routes.inbound.match-authservice-route" -}}
{{- $ctx := index . 0 -}}
{{- $podSelector := index . 1 -}}
{{- $ports := index . 2 -}}

{{- $localLabels := dict -}}
{{- if and $podSelector (not $podSelector.matchExpressions) -}}
  {{- $localLabels = dig "matchLabels" dict $podSelector -}}
{{- end -}}

{{- $matches := list -}}
{{- if and $localLabels $ports -}}
  {{- range $name, $route := dig "inbound" dict ($ctx.Values.routes | default dict) -}}
    {{- if and (dig "enabled" false $route) (dig "authservice" "enabled" false $route) -}}
      {{- $routeSelector := $route.selector | default (dict "app.kubernetes.io/name" $name) -}}
      {{- /* containerPort wins over port, same as the route's own NetworkPolicy */ -}}
      {{- $workloadPort := $route.containerPort | default $route.port | default "" -}}
      {{- if kindIs "string" $workloadPort -}}
        {{- $workloadPort = tpl $workloadPort $ctx -}}
      {{- end -}}
      {{- $workloadPort = int64 $workloadPort -}}
      {{- /* port lists may hold int64 or float64 depending on how they were
             parsed, so cast each element instead of using `has` */ -}}
      {{- $portMatch := false -}}
      {{- range $port := $ports -}}
        {{- if eq (int64 $port) $workloadPort -}}
          {{- $portMatch = true -}}
        {{- end -}}
      {{- end -}}
      {{- if and (eq ($routeSelector | toYaml) ($localLabels | toYaml)) $portMatch -}}
        {{- /* route.service may be a template string and/or an FQDN; we want
               the plain local Service name */ -}}
        {{- $service := tpl (default $name $route.service) $ctx | splitList "." | first -}}
        {{- $port := $route.port | default "" -}}
        {{- if kindIs "string" $port -}}
          {{- $port = tpl $port $ctx -}}
        {{- end -}}
        {{- $port = int64 $port | default $workloadPort -}}
        {{- $matches = append $matches (dict "route" $name "service" $service "port" (toString $port)) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- if $matches -}}
  {{- $distinct := dict -}}
  {{- range $match := $matches -}}
    {{- $_ := set $distinct (printf "%s:%s" $match.service $match.port) $match -}}
  {{- end -}}
  {{- if gt (len $distinct) 1 -}}
    {{- $names := list -}}
    {{- range $match := $matches -}}{{- $names = append $names $match.route -}}{{- end -}}
    {{- fail (printf "Ingress entry with selector %s matches multiple authservice routes with different services: %s" ($localLabels | toYaml) (join ", " $names)) -}}
  {{- end -}}
  {{- (index $matches 0) | toYaml -}}
{{- end -}}
{{- end -}}
