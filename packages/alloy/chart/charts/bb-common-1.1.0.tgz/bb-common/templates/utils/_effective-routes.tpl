{{- /*
Effective (resolved) settings derived from the routes configuration.

Istio-domain effective values live in _effective-istio.tpl; note that
"bb-common.istio.waypoint.enabled" there is derived from the helper below.
*/ -}}

{{- /* True when any enabled inbound route enables authservice (OIDC ext_authz), which is
       what drives auto-creation of the shared ambient waypoint. */ -}}
{{- define "bb-common.routes.authservice.enabled" -}}
{{- $ctx := . -}}
{{- $found := false -}}
{{- $inbound := dig "inbound" dict ($ctx.Values.routes | default dict) -}}
{{- range $name, $route := $inbound -}}
{{- if and (dig "enabled" false $route) (dig "authservice" "enabled" false $route) -}}
{{- $found = true -}}
{{- end -}}
{{- end -}}
{{- $found -}}
{{- end -}}
