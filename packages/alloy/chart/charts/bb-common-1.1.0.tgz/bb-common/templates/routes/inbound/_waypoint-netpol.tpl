{{- /*
Ambient-waypoint companion NetworkPolicy for an inbound route.

With istio.io/ingress-use-waypoint, the ingress gateway connects to the WAYPOINT
pod over HBONE (15008), not to the application workload. The standard route
NetworkPolicy selects the workload (route.selector), so gateway->waypoint traffic
is dropped and requests fail with a 503. This emits the missing allowance,
selecting the waypoint pod by its gateway.networking.k8s.io/gateway-name label.
*/}}
{{- define "bb-common.routes.inbound.waypoint-netpol" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- $gatewayParts := split "/" (index $route.gateways 0) }}
  {{- $istioNamespace := $gatewayParts._0 }}
  {{- $istioGateway := $gatewayParts._1 }}
  {{- $waypointName := include "bb-common.istio.waypoint.name" $ctx }}

  {{- $netpol := dict }}
  {{- $_ := set $netpol "apiVersion" "networking.k8s.io/v1" }}
  {{- $_ := set $netpol "kind" "NetworkPolicy" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "allow-ingress-to-%s-waypoint-15008-from-ns-%s-pod-%s" $name $istioNamespace $istioGateway) "routes") | trim }}
  {{- $metadata := dict "name" $resourceName "namespace" $ctx.Release.Namespace }}
  {{- if $route.metadata }}
    {{- if $route.metadata.labels }}
      {{- $_ := set $metadata "labels" $route.metadata.labels }}
    {{- end }}
    {{- if $route.metadata.annotations }}
      {{- $_ := set $metadata "annotations" $route.metadata.annotations }}
    {{- end }}
  {{- end }}
  {{- $_ := set $netpol "metadata" $metadata }}

  {{- $spec := dict }}
  {{- $_ := set $spec "podSelector" (dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" $waypointName)) }}
  {{- $_ := set $spec "policyTypes" (list "Ingress") }}

  {{- $namespaceSelector := dict "matchLabels" (dict "kubernetes.io/metadata.name" $istioNamespace) }}
  {{- $podSelector := dict "matchLabels" (dict "app.kubernetes.io/name" $istioGateway "istio" "ingressgateway") }}
  {{- $from := dict "namespaceSelector" $namespaceSelector "podSelector" $podSelector }}
  {{- $ingress := dict "from" (list $from) "ports" (list (dict "port" 15008 "protocol" "TCP")) }}
  {{- $_ := set $spec "ingress" (list $ingress) }}

  {{- $_ := set $netpol "spec" $spec }}

  {{- $netpol | toYaml }}
{{- end }}
