{{- define "bb-common.routes.inbound.render" }}
  {{- $ctx := . }}
  {{- $resources := list }}
  {{- $istioAvailable := $ctx.Capabilities.APIVersions.Has "networking.istio.io/v1" }}

  {{- if and $istioAvailable $ctx.Values.routes $ctx.Values.routes.inbound }}

    {{- /* Ambient: auto-create the shared waypoint Gateway once when any inbound route
           enables authservice (ext_authz is enforced at the waypoint). */}}
    {{- if eq (include "bb-common.istio.waypoint.enabled" $ctx) "true" }}
      {{- $resources = append $resources (include "bb-common.routes.inbound.waypoint" (list $ctx) | fromYaml) }}
    {{- end }}

    {{- range $name, $route := $ctx.Values.routes.inbound }}
      {{- if $route.enabled }}

        {{- /* Collect VirtualService object */}}
        {{- $virtualService := include "bb-common.routes.inbound.virtual-service" (list $ctx $name $route) | fromYaml }}
        {{- $resources = append $resources $virtualService }}

        {{- /* Collect ServiceEntry object */}}
        {{- $serviceEntry := include "bb-common.routes.inbound.service-entry" (list $ctx $name $route) | fromYaml }}
        {{- $resources = append $resources $serviceEntry }}

        {{- /* Collect NetworkPolicy and AuthorizationPolicy objects if selector is specified or can be inferred */}}
        {{- $effectiveSelector := $route.selector }}
        {{- if not $effectiveSelector }}
          {{- $effectiveSelector = dict "app.kubernetes.io/name" $name }}
        {{- end }}

        {{- if $effectiveSelector }}
          {{- $routeWithSelector := merge $route (dict "selector" $effectiveSelector) }}

          {{- /* Only create NetworkPolicy if networkPolicies.enabled is true */}}
          {{- if dig "enabled" false ($ctx.Values.networkPolicies | default dict) }}
            {{- $networkPolicy := include "bb-common.routes.inbound.netpol" (list $ctx $name $routeWithSelector) | fromYaml }}
            {{- $resources = append $resources $networkPolicy }}
          {{- end }}

          {{- /* Create AuthorizationPolicy when the effective authorizationPolicies setting is enabled */}}
          {{- if eq (include "bb-common.istio.authorization-policies.enabled" $ctx) "true" }}
            {{- $authorizationPolicy := include "bb-common.routes.inbound.authz" (list $ctx $name $routeWithSelector) | fromYaml }}
            {{- $resources = append $resources $authorizationPolicy }}
          {{- end }}

          {{- /* Protect this route with authservice (OIDC ext_authz): RequestAuthentication
                 + CUSTOM/DENY AuthorizationPolicies, bound from the route's own
                 service/selector. */}}
          {{- if dig "authservice" "enabled" false $route }}
            {{- $resources = concat $resources (include "bb-common.routes.inbound.authservice" (list $ctx $name $routeWithSelector) | fromYamlArray) }}

            {{- /* Waypoint netpols for this protected route, when netpols are managed
                   here and the waypoint is the enforcement point: ingress gateway ->
                   waypoint pod on HBONE (ingress-use-waypoint routes north-south
                   traffic through the waypoint, not the workload), and waypoint ->
                   authservice (the waypoint, not the workload, makes the ext_authz
                   call). */}}
            {{- if and (dig "enabled" false ($ctx.Values.networkPolicies | default dict)) (eq (include "bb-common.istio.waypoint.enabled" $ctx) "true") }}
              {{- $waypointNetpol := include "bb-common.routes.inbound.waypoint-netpol" (list $ctx $name $routeWithSelector) | fromYaml }}
              {{- $resources = append $resources $waypointNetpol }}
              {{- $authserviceEgressNetpol := include "bb-common.routes.inbound.authservice-egress-netpol" (list $ctx $name $routeWithSelector) | fromYaml }}
              {{- $resources = append $resources $authserviceEgressNetpol }}
            {{- end }}
          {{- end }}
        {{- end }}

      {{- end }}
    {{- end }}
  {{- end }}

  {{- $resources = include "bb-common.utils.dedupe" $resources | fromYamlArray }}

  {{- range $resource := $resources }}
    {{- print "---" | nindent 0 }}
    {{- $resource | toYaml | nindent 0 }}
  {{- end }}
{{- end }}
