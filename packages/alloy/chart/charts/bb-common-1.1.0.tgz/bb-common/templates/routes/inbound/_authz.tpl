{{- define "bb-common.routes.inbound.authz" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- $gatewayParts := split "/" (index $route.gateways 0) }}
  {{- $istioNamespace := $gatewayParts._0 }}
  {{- $istioGateway := $gatewayParts._1 }}

  {{- /* Build AuthorizationPolicy resource */}}
  {{- $authz := dict }}
  {{- $_ := set $authz "apiVersion" "security.istio.io/v1" }}
  {{- $_ := set $authz "kind" "AuthorizationPolicy" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "%s-%s-authz-policy" $name $istioGateway) "routes") | trim }}
  {{- $metadata := dict "name" $resourceName "namespace" $ctx.Release.Namespace }}
  {{- if $route.metadata }}
    {{- if $route.metadata.labels }}
      {{- $_ := set $metadata "labels" $route.metadata.labels }}
    {{- end }}
    {{- if $route.metadata.annotations }}
      {{- $_ := set $metadata "annotations" $route.metadata.annotations }}
    {{- end }}
  {{- end }}
  {{- $_ := set $authz "metadata" $metadata }}

  {{- $spec := dict }}
  {{- if and (eq (include "bb-common.istio.waypoint.enabled" $ctx) "true") (dig "authservice" "enabled" false $route) }}
    {{- /* Ambient waypoint: this route's Service is expected to be waypoint-enrolled
           (authservice protects it), so its ingress RBAC is enforced at the waypoint.
           Bind with targetRefs — a workload `selector` would attach this ALLOW at
           the pod (ztunnel), never evaluated at the waypoint alongside the
           namespace-wide deny-all, denying authenticated ingress. Routes WITHOUT
           authservice keep the selector binding: their Services are not
           waypoint-enrolled, so a targetRefs policy would be enforced nowhere,
           silently dropping the gateway-only restriction. */}}
    {{- /* route.service may be a template string and/or an FQDN; targetRefs wants
           the local Service name */}}
    {{- $serviceName := tpl (default $name $route.service) $ctx | splitList "." | first }}
    {{- $_ := set $spec "targetRefs" (list (dict "group" "" "kind" "Service" "name" $serviceName)) }}
  {{- else }}
    {{- $_ := set $spec "selector" (dict "matchLabels" $route.selector) }}
  {{- end }}
  {{- $_ := set $spec "action" "ALLOW" }}

  {{- $rule := dict }}
  {{- $source := dict "namespaces" (list $istioNamespace) "principals" (list (printf "cluster.local/ns/%s/sa/%s-ingressgateway-service-account" $istioNamespace $istioGateway)) }}
  {{- $_ := set $rule "from" (list (dict "source" $source)) }}
  {{- $_ := set $spec "rules" (list $rule) }}

  {{- $_ := set $authz "spec" $spec }}
  {{- $authz | toYaml }}
{{- end }}
