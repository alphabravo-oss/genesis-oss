{{/* Print a Loki destination Alloy config components */}}
{{/* Inputs: . (root object),  destination (string, name of destination), destinationName (name of this destination) */}}
{{- define "destinations.loki.alloy" }}
{{- with .destination }}
otelcol.exporter.loki {{ include "helper.alloy_name" $.destinationName | quote }} {
  forward_to = [{{ include "destinations.loki.alloy.loki.logs.target" (dict "destination" . "destinationName" $.destinationName) }}]
} // otelcol.exporter.loki "{{ include "helper.alloy_name" $.destinationName }}"
{{- if .logProcessingStages }}

loki.process {{ include "helper.alloy_name" $.destinationName | quote }} {
{{ .logProcessingStages | indent 2 }}
  forward_to = [loki.write.{{ include "helper.alloy_name" $.destinationName }}.receiver]
} // loki.process "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}

loki.write {{ include "helper.alloy_name" $.destinationName | quote }} {
  endpoint {
{{- if .urlFrom }}
    url = {{ .urlFrom }}
{{- else }}
    url = {{ .url | quote }}
{{- end }}
{{- if .timeout }}
    remote_timeout = {{ .timeout | quote }}
{{- end }}
    retry_on_http_429 = {{ .retryOnHttp429 }}
{{- if .batchSize }}
    batch_size = {{ .batchSize | quote }}
{{- end }}
{{- if .batchWait }}
    batch_wait = {{ .batchWait | quote }}
{{- end }}
{{- if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tenantId")) "true" }}
    tenant_id = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tenantId" "nonsensitive" true) }}
{{- end }}
{{- if or .extraHeaders .extraHeadersFrom }}
    headers = {
{{- range $key, $value := .extraHeaders }}
      {{ $key | quote }} = {{ $value | quote }},
{{- end }}
{{- range $key, $value := .extraHeadersFrom }}
      {{ $key | quote }} = {{ $value }},
{{- end }}
    }
{{- end }}
{{- if .proxyURL }}
    proxy_url = {{ .proxyURL | quote }}
{{- end }}
{{- if .noProxy }}
    no_proxy = {{ .noProxy | quote }}
{{- end }}
{{- if .proxyConnectHeader }}
    proxy_connect_header = {
{{- range $k, $v := .proxyConnectHeader }}
      {{ $k | quote }} = {{ $v | toJson }},
{{- end }}
    }
{{- end }}
{{- if .proxyFromEnvironment }}
    proxy_from_environment = {{ .proxyFromEnvironment }}
{{- end }}
{{- if eq (include "secrets.authType" .) "basic" }}
    basic_auth {
      username = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.username" "nonsensitive" true) }}
      password = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.password") }}
    }
{{- else if eq (include "secrets.authType" .) "bearerToken" }}
{{- if .auth.bearerTokenFile }}
    bearer_token_file = {{ .auth.bearerTokenFile | quote }}
{{- else }}
    bearer_token = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.bearerToken") }}
{{- end }}
{{- else if eq (include "secrets.authType" .) "oauth2" }}
    oauth2 {
      client_id = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientId" "nonsensitive" true) }}
      {{- if eq .auth.oauth2.clientSecretFile "" }}
      client_secret = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientSecret") }}
      {{- else }}
      client_secret_file = {{ .auth.oauth2.clientSecretFile | quote }}
      {{- end }}
      {{- if .auth.oauth2.endpointParams }}
      endpoint_params = {
      {{- range $k, $v := .auth.oauth2.endpointParams }}
        {{ $k }} = {{ $v | toJson }},
      {{- end }}
      }
      {{- end }}
      {{- if .auth.oauth2.proxyURL }}
      proxy_url = {{ .auth.oauth2.proxyURL | quote }}
      {{- end }}
      {{- if .auth.oauth2.noProxy }}
      no_proxy = {{ .auth.oauth2.noProxy | quote }}
      {{- end }}
      {{- if .auth.oauth2.proxyFromEnvironment }}
      proxyFromEnvironment = {{ .auth.oauth2.proxyFromEnvironment }}
      {{- end }}
      {{- if .auth.oauth2.proxyConnectHeader }}
      proxy_connect_header = {
      {{- range $k, $v := .auth.oauth2.proxyConnectHeader }}
        {{ $k | quote }} = {{ $v | toJson }},
      {{- end }}
      }
      {{- end }}
      {{- if .auth.oauth2.scopes }}
      scopes = {{ .auth.oauth2.scopes | toJson }}
      {{- end }}
      {{- if .auth.oauth2.tokenURL }}
      token_url = {{ .auth.oauth2.tokenURL | quote }}
      {{- end }}
      {{- if .auth.oauth2.tls }}
      tls_config {
        insecure_skip_verify = {{ .auth.oauth2.tls.insecureSkipVerify | default false }}
        {{- if .auth.oauth2.tls.caFile }}
        ca_file = {{ .auth.oauth2.tls.caFile | quote }}
        {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.ca")) "true" }}
        ca_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.ca" "nonsensitive" true) }}
        {{- end }}
        {{- if .auth.oauth2.tls.certFile }}
        cert_file = {{ .auth.oauth2.tls.certFile | quote }}
        {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.cert")) "true" }}
        cert_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.cert" "nonsensitive" true) }}
        {{- end }}
        {{- if .auth.oauth2.tls.keyFile }}
        key_file = {{ .auth.oauth2.tls.keyFile | quote }}
        {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.key")) "true" }}
        key_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.key") }}
        {{- end }}
      }
      {{- end }}
    }
{{- end }}
{{- if .tls }}
    tls_config {
      insecure_skip_verify = {{ .tls.insecureSkipVerify | default false }}
      {{- if .tls.caFile }}
      ca_file = {{ .tls.caFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.ca")) "true" }}
      ca_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.ca" "nonsensitive" true) }}
      {{- end }}
      {{- if .tls.certFile }}
      cert_file = {{ .tls.certFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.cert")) "true" }}
      cert_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.cert" "nonsensitive" true) }}
      {{- end }}
      {{- if .tls.keyFile }}
      key_file = {{ .tls.keyFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.key")) "true" }}
      key_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.key") }}
      {{- end }}
    }
{{- end }}
    min_backoff_period = {{ .minBackoffPeriod | quote }}
    max_backoff_period = {{ .maxBackoffPeriod | quote }}
    max_backoff_retries = {{ .maxBackoffRetries | quote }}
  }
  external_labels = {
{{- range $label := .clusterLabels }}
    {{ include "escape_label" $label | quote }} = {{ $.Values.cluster.nameFrom | default ($.Values.cluster.name | quote) }},
{{- end }}
{{- if .extraLabels }}
  {{- range $k, $v := .extraLabels }}
    {{ $k }} = {{ $v | quote }},
  {{- end }}
{{- end }}
{{- if .extraLabelsFrom }}
  {{- range $k, $v := .extraLabelsFrom }}
    {{ $k }} = {{ $v }},
  {{- end }}
{{- end }}
  }
{{- if .writeAheadLog.enabled }}
  wal {
    enabled = true
{{- if .writeAheadLog.minReadFrequency }}
    min_read_frequency = {{ .writeAheadLog.minReadFrequency | quote }}
{{- end }}
{{- if .writeAheadLog.maxReadFrequency }}
    max_read_frequency = {{ .writeAheadLog.maxReadFrequency | quote }}
{{- end }}
{{- if .writeAheadLog.drainTimeout }}
    drain_timeout = {{ .writeAheadLog.drainTimeout | quote }}
{{- end }}
{{- if .writeAheadLog.maxSegmentAge }}
    max_segment_age = {{ .writeAheadLog.maxSegmentAge | quote }}
{{- end }}
  }
{{- end }}
} // loki.write "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}
{{- end }}

{{- define "secrets.list.loki" -}}
- tenantId
- auth.username
- auth.password
- auth.bearerToken
- auth.oauth2.clientId
- auth.oauth2.clientSecret
- auth.oauth2.tls.ca
- auth.oauth2.tls.cert
- auth.oauth2.tls.key
- tls.ca
- tls.cert
- tls.key
{{- end -}}

{{- define "destinations.loki.alloy.loki.logs.target" }}
{{- if .destination.logProcessingStages -}}
loki.process.{{ include "helper.alloy_name" .destinationName }}.receiver
{{- else -}}
loki.write.{{ include "helper.alloy_name" .destinationName }}.receiver
{{- end -}}
{{- end }}
{{- define "destinations.loki.alloy.otlp.logs.target" }}otelcol.exporter.loki.{{ include "helper.alloy_name" .destinationName }}.input{{ end -}}

{{- define "destinations.loki.supports_metrics" }}false{{ end -}}
{{- define "destinations.loki.supports_logs" }}true{{ end -}}
{{- define "destinations.loki.supports_traces" }}false{{ end -}}
{{- define "destinations.loki.supports_profiles" }}false{{ end -}}
{{- define "destinations.loki.ecosystem" }}loki{{ end -}}
