{{ define "feature.costMetrics.opencost.allowList" }}
{{- $allowList := list }}
{{ if .Values.opencost.metricsTuning.useDefaultAllowList }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") (.Files.Get "default-allow-lists/opencost.yaml" | fromYamlArray) -}}
{{ end }}
{{ if .Values.opencost.metricsTuning.includeMetrics }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") .Values.opencost.metricsTuning.includeMetrics -}}
{{ end }}
{{ $allowList | uniq | toYaml }}
{{ end }}

{{- define "feature.costMetrics.opencost.alloy" }}
{{- $namespace := .Values.opencost.namespace }}
{{- if dig "opencost" "deploy" false (.telemetryServices | default dict) }}
  {{- $namespace = (dig "opencost" "namespaceOverride" false (.telemetryServices | default dict) | default .Release.Namespace) }}
{{- end }}
{{- $metricAllowList := include "feature.costMetrics.opencost.allowList" . | fromYamlArray }}
{{- $metricDenyList := .Values.opencost.metricsTuning.excludeMetrics }}
{{- $labelSelectors := list }}
{{- if .Values.opencost.labelMatchers }}
  {{- range $label, $value := .Values.opencost.labelMatchers }}
    {{- $labelSelectors = append $labelSelectors (printf "%s=%s" $label $value) }}
  {{- end }}
{{- else if dig "opencost" "deploy" false (.telemetryServices | default dict) }}
  {{- $labelSelectors = append $labelSelectors (printf "app.kubernetes.io/instance=%s" .Release.Name) }}
  {{- $labelSelectors = append $labelSelectors "app.kubernetes.io/name=opencost" }}
{{- end }}

discovery.kubernetes "opencost" {
  role = "pod"
  selectors {
    role = "pod"
    label = {{ $labelSelectors | join "," | quote }}
  }
{{- if $namespace }}
  namespaces {
    names = [{{ $namespace | quote }}]
  }
{{- end }}
} // discovery.kubernetes "opencost"

discovery.relabel "opencost" {
  targets = discovery.kubernetes.opencost.targets
  rule {
    source_labels = ["__meta_kubernetes_pod_node_name"]
    action = "replace"
    target_label = "instance"
  }
{{- if .Values.opencost.extraDiscoveryRules }}
{{ .Values.opencost.extraDiscoveryRules | indent 2 }}
{{- end }}
} // discovery.relabel "opencost"

prometheus.scrape "opencost" {
  targets      = discovery.relabel.opencost.output
  job_name     = {{ .Values.opencost.jobLabel | quote }}
  honor_labels = true
  scrape_interval = {{ .Values.opencost.scrapeInterval | default .Values.global.scrapeInterval | quote }}
  scrape_timeout = {{ .Values.opencost.scrapeTimeout | default .Values.global.scrapeTimeout | quote }}
  scrape_protocols = {{ include "helper.scrapeProtocols" . }}
  scrape_classic_histograms = {{ .Values.global.scrapeClassicHistograms }}
  scrape_native_histograms = {{ .Values.global.scrapeNativeHistograms }}
  convert_classic_histograms_to_nhcb = {{ .Values.global.convertClassicHistogramsToNhcb }}
  clustering {
    enabled = true
  }
{{- if or $metricAllowList $metricDenyList .Values.opencost.extraMetricProcessingRules }}
  forward_to = [prometheus.relabel.opencost.receiver]
} // prometheus.scrape "opencost"

prometheus.relabel "opencost" {
  max_cache_size = {{ .Values.opencost.maxCacheSize | default .Values.global.maxCacheSize | int }}
{{- if $metricAllowList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricAllowList | join "|" | quote }}
    action = "keep"
  }
{{- end }}
{{- if $metricDenyList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricDenyList | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .Values.opencost.extraMetricProcessingRules }}
{{ .Values.opencost.extraMetricProcessingRules | indent 2 }}
{{- end }}
{{- end }}
  forward_to = argument.metrics_destinations.value
} // prometheus.relabel "opencost"
{{- end }}
