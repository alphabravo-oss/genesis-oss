{{- define "features.annotationAutodiscovery.enabled" }}{{ .Values.annotationAutodiscovery.enabled }}{{- end }}

{{- define "features.annotationAutodiscovery.include" }}
{{- if .Values.annotationAutodiscovery.enabled -}}
{{- $destinations := include "features.annotationAutodiscovery.destinations" . | fromYamlArray }}
// Feature: Annotation Autodiscovery
{{- include "feature.annotationAutodiscovery.module" .Subcharts.annotationAutodiscovery }}
annotation_autodiscovery "feature" {
  metrics_destinations = [
    {{ include "destinations.alloy.targets" (dict "destinations" $.Values.destinations "destinationNames" $destinations "type" "metrics" "ecosystem" "prometheus") | indent 4 | trim }}
  ]
}
{{- end -}}
{{- end -}}

{{- define "features.annotationAutodiscovery.destinations" }}
{{- if .Values.annotationAutodiscovery.enabled -}}
{{- include "destinations.get" (dict "destinations" $.Values.destinations "type" "metrics" "ecosystem" "prometheus" "filter" $.Values.annotationAutodiscovery.destinations) -}}
{{- end -}}
{{- end -}}

{{- define "features.annotationAutodiscovery.destinations.isTranslating" }}
{{- $isTranslating := false -}}
{{- $destinations := include "features.annotationAutodiscovery.destinations" . | fromYamlArray -}}
{{ range $destination := $destinations -}}
  {{- $destinationEcosystem := include "destination.getEcosystem" (deepCopy $ | merge (dict "destination" $destination)) -}}
  {{- if ne $destinationEcosystem "prometheus" -}}
    {{- $isTranslating = true -}}
  {{- end -}}
{{- end -}}
{{- $isTranslating -}}
{{- end -}}

{{- define "features.annotationAutodiscovery.collector.values" }}{{- end -}}

{{- define "features.annotationAutodiscovery.validate" }}
{{- if .Values.annotationAutodiscovery.enabled -}}
  {{- $featureKey := "annotationAutodiscovery" }}
  {{- $featureName := "Annotation Autodiscovery" }}

  {{- $destinations := include "features.annotationAutodiscovery.destinations" . | fromYamlArray }}
  {{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $destinations "type" "metrics" "ecosystem" "prometheus" "featureName" $featureName) }}

  {{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
  {{- include "collectors.validate.collectorIsAssigned" (dict "Values" $.Values "collectorName" $collectorName "featureKey" $featureKey "featureName" $featureName) }}
  {{- include "collectors.validate.clusteringEnabled" (dict "Values" $.Values "Files" $.Files "collectorName" $collectorName "featureName" $featureName) }}

  {{- include "feature.annotationAutodiscovery.validate" (dict "Values" $.Values.annotationAutodiscovery) }}
{{- end -}}
{{- end -}}

{{- define "features.annotationAutodiscovery.chooseCollector" -}}{{- end -}}
