{{- define "bb-common.routes.inbound.service-entry" }}
  {{- $ctx := index . 0 }}
  {{- $name := index . 1 }}
  {{- $route := index . 2 }}

  {{- /* Build ServiceEntry resource */}}
  {{- $se := dict }}
  {{- $_ := set $se "apiVersion" "networking.istio.io/v1" }}
  {{- $_ := set $se "kind" "ServiceEntry" }}

  {{- $resourceName := include "bb-common.prepend-release-name" (list $ctx (printf "%s-internal" $name) "routes") | trim }}
  {{- $metadata := dict "name" $resourceName "namespace" $ctx.Release.Namespace }}
  {{- if $route.metadata }}
    {{- if $route.metadata.labels }}
      {{- $_ := set $metadata "labels" $route.metadata.labels }}
    {{- end }}
    {{- if $route.metadata.annotations }}
      {{- $_ := set $metadata "annotations" $route.metadata.annotations }}
    {{- end }}
  {{- end }}
  {{- $_ := set $se "metadata" $metadata }}

  {{- $spec := dict }}
  {{- $hosts := list }}
  {{- range $route.hosts }}
    {{- $hosts = append $hosts (tpl . $ctx) }}
  {{- end }}
  {{- $_ := set $spec "hosts" $hosts }}
  {{- $_ := set $spec "location" "MESH_EXTERNAL" }}
  {{- $defaultResolution := "DNS" }}
  {{- $hasWildcardHost := false }}
  {{- range $hosts }}
    {{- if contains "*" . }}
      {{- $hasWildcardHost = true }}
    {{- end }}
  {{- end }}
  {{- if and (not $route.resolution) $hasWildcardHost }}
    {{- $defaultResolution = "NONE" }}
  {{- end }}
  {{- $_ := set $spec "resolution" (default $defaultResolution $route.resolution | upper) }}

  {{- $ports := list }}
  {{- $httpsPort := dict "name" "https" "number" 443 "protocol" "HTTPS" }}
  {{- $ports = append $ports $httpsPort }}
  {{- $_ := set $spec "ports" $ports }}

  {{- $_ := set $se "spec" $spec }}
  {{- $se | toYaml }}
{{- end }}
