{{- define "bb-common.istio.ambient.enabled" -}}
{{- $istio := .Values.istio | default dict -}}
{{- dig "ambient" "enabled" false $istio -}}
{{- end -}}

{{- define "bb-common.istio.sidecar.enabled" -}}
{{- if eq (include "bb-common.istio.ambient.enabled" .) "true" -}}
false
{{- else -}}
{{- $istio := .Values.istio | default dict -}}
{{- dig "sidecar" "enabled" false $istio -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.istio.authorization-policies.enabled" -}}
{{- $ctx := . -}}
{{- $default := false -}}
{{- if kindIs "slice" . -}}
{{- $ctx = index . 0 -}}
{{- $default = index . 1 -}}
{{- end -}}
{{- if eq (include "bb-common.istio.ambient.enabled" $ctx) "true" -}}
true
{{- else -}}
{{- $istio := $ctx.Values.istio | default dict -}}
{{- dig "authorizationPolicies" "enabled" $default $istio -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.istio.authorization-policies.generate-from-netpol.enabled" -}}
{{- $ctx := . -}}
{{- $default := false -}}
{{- if kindIs "slice" . -}}
{{- $ctx = index . 0 -}}
{{- $default = index . 1 -}}
{{- end -}}
{{- if eq (include "bb-common.istio.ambient.enabled" $ctx) "true" -}}
true
{{- else -}}
{{- $istio := $ctx.Values.istio | default dict -}}
{{- dig "authorizationPolicies" "generateFromNetpol" $default $istio -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.network-policies.hbone-port-injection.enabled" -}}
{{- if eq (include "bb-common.istio.ambient.enabled" .) "true" -}}
true
{{- else -}}
{{- $networkPolicies := .Values.networkPolicies | default dict -}}
{{- dig "hbonePortInjection" "enabled" false $networkPolicies -}}
{{- end -}}
{{- end -}}

{{- define "bb-common.warn.ambient" -}}
{{- $istio := .Values.istio | default dict -}}
{{- if and (eq (include "bb-common.istio.ambient.enabled" .) "true") (dig "sidecar" "enabled" false $istio) -}}
# WARNING: istio.ambient.enabled=true ignores istio.sidecar.enabled=true. Ambient mode does not render Istio Sidecar resources.
{{- end -}}
{{- end -}}
